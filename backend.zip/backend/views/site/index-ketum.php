<?php

/* @var $this yii\web\View */

$this->title = 'E-Serikat';
$noKegiatan=1;
$noKegiatanRutin=1;
?>
<div class="site-index">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><i class="fa fa-user-secret"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Jumlah Ketua</span>
                            <span class="info-box-number"><?=$jumlahKetua?></span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-red"><i class="fa fa-user"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Jumlah Departemen</span>
                            <span class="info-box-number"><?=$jumlahDepartemen?></span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-green"><i class="fa fa-users"></i></span>

                        <div class="info-box-content">
                            <span class="info-box-text">Jumlah Seksi</span>
                            <span class="info-box-number"><?=$jumlahSeksi?></span>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Kegiatan</h3>

                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Kegiatan</th>
                                        <th>Judul Kegiatan</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>    
                                <tbody>
                                    <?php foreach ($dataKegiatan as $key => $value) { ?>
                                        <tr>
                                            <td><?=$noKegiatan++?></td>
                                            <td><?=$value->activity_code?></td>
                                            <td><?=$value->title?></td>
                                            <td>
                                            <?php if($value->role == '1')
                                            { ?>
                                                <span class="label label-info">Super Admin</span>
                                            <?php }
                                            else if($value->role == '2')
                                            { ?>
                                                <span class="label label-info">Ketua Umum</span>
                                            <?php }
                                            else if($value->role == '3')
                                            { ?>
                                                <span class="label label-info">Sekretaris Umum</span>
                                            <?php }
                                            else if($value->role == '4')
                                            { ?>
                                                <span class="label label-info">Sekretariat</span>
                                            <?php }
                                            else if($value->role == '5')
                                            { ?>
                                                <span class="label label-info">Bendahara</span>
                                            <?php }
                                            else if($value->role == '6')
                                            { ?>
                                                <span class="label label-info">Ketua</span>
                                            <?php }
                                            else if($value->role == '7')
                                            { ?>
                                                <span class="label label-info">Departemen</span>
                                            <?php }
                                            else if($value->role == '8')
                                            { ?>
                                                <span class="label label-info">Seksi</span>
                                            <?php } ?>
                                            </td>
                                            <td>
                                            <?php if($value->finance_status == '0')
                                            { ?>
                                                <span class="label label-info">Belum Dikonfirmasi</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '1' && $value->chief_status == '1')
                                            { ?>
                                                <span class="label label-success">Diterima</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '0' && $value->chief_status == '0')
                                            { ?>
                                                <span class="label label-success">Diterima Bendahara</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '1' && $value->chief_status == '0')
                                            { ?>
                                                <span class="label label-success">Diterima Departemen</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '2' && $value->chief_status == '0')
                                            { ?>
                                                <span class="label label-warning">Draft Departemen</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '1' && $value->chief_status == '2')
                                            { ?>
                                                <span class="label label-warning">Draft Ketua</span>
                                            <?php }
                                            else if($value->finance_status == '2')
                                            { ?>
                                                <span class="label label-warning">Draft Bendahara</span>
                                            <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                    <!-- /.box-footer -->
                </div>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Kegiatan Rutin</h3>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table no-margin">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode Kegiatan</th>
                                        <th>Judul Kegiatan</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dataKegiatanRutin as $key => $value) { ?>
                                        <tr>
                                            <td><?=$noKegiatanRutin++?></td>
                                            <td><?=$value->activity_code?></td>
                                            <td><?=$value->title?></td>
                                            <td>
                                            <?php if($value->role == '1')
                                            { ?>
                                                <span class="label label-info">Super Admin</span>
                                            <?php }
                                            else if($value->role == '2')
                                            { ?>
                                                <span class="label label-info">Ketua Umum</span>
                                            <?php }
                                            else if($value->role == '3')
                                            { ?>
                                                <span class="label label-info">Sekretaris Umum</span>
                                            <?php }
                                            else if($value->role == '4')
                                            { ?>
                                                <span class="label label-info">Sekretariat</span>
                                            <?php }
                                            else if($value->role == '5')
                                            { ?>
                                                <span class="label label-info">Bendahara</span>
                                            <?php }
                                            else if($value->role == '6')
                                            { ?>
                                                <span class="label label-info">Ketua</span>
                                            <?php }
                                            else if($value->role == '7')
                                            { ?>
                                                <span class="label label-info">Departemen</span>
                                            <?php }
                                            else if($value->role == '8')
                                            { ?>
                                                <span class="label label-info">Seksi</span>
                                            <?php } ?>
                                            </td>
                                            <td>
                                            <?php if($value->finance_status == '0')
                                            { ?>
                                                <span class="label label-info">Belum Dikonfirmasi</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '1' && $value->chief_status == '1')
                                            { ?>
                                                <span class="label label-success">Diterima</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '0' && $value->chief_status == '0')
                                            { ?>
                                                <span class="label label-success">Diterima Bendahara</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '1' && $value->chief_status == '0')
                                            { ?>
                                                <span class="label label-success">Diterima Departemen</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '2' && $value->chief_status == '0')
                                            { ?>
                                                <span class="label label-warning">Draft Departemen</span>
                                            <?php }
                                            else if($value->finance_status == '1' && $value->department_status == '1' && $value->chief_status == '2')
                                            { ?>
                                                <span class="label label-warning">Draft Ketua</span>
                                            <?php }
                                            else if($value->finance_status == '2')
                                            { ?>
                                                <span class="label label-warning">Draft Bendahara</span>
                                            <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.box-body -->
                    <!-- /.box-footer -->
                </div>
            </div>
        </div>
    </section>

</div>